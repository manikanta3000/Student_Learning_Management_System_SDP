const Orders = [
    {
        productName:'Ferrrai Daytona SP3',
        productNumber:'85631',
        paymentStatus:'Due',
        shipping:'pending'
    },
    {
        productName:'Ferrari 812 GTS',
        productNumber:'85631',
        paymentStatus:'Due',
        shipping:'Declined'
    },
    {
        productName:'Ferrai Roma Spider',
        productNumber:'85631',
        paymentStatus:'Due',
        shipping:'Delivered'
    },
    {
        productName:'Ferrari 296 GTS',
        productNumber:'85631',
        paymentStatus:'Due',
        shipping:'pending'
    },
    {
        productName:'Ferrari SF90 stradale',
        productNumber:'85631',
        paymentStatus:'Due',
        shipping:'Delivered'
    }
]